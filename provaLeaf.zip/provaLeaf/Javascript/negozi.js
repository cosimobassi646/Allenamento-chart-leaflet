const negozi = [
    {
        city: "Milano",
        latitude: 45.4642,
        longitude: 9.1900,
        address: "Via Giovanni Battista Pirelli, 30, 20124 Milano MI, Italy"
    },
    {
        city: "Roma",
        latitude: 41.9028,
        longitude: 12.4964,
        address: "Via della Magliana, 856, 00148 Roma RM, Italy"
    },
    {
        city: "Scandicci",
        latitude: 43.755789429869616, 
        longitude: 11.197873561300858,
        address: "Via Francesco Gioli, 16, 50018 scandicci FI, Italy"
    },
    {
        city: "Torino",
        latitude: 45.0703,
        longitude: 7.6869,
        address: "Corso Vittorio Emanuele II, 31, 10125 Torino TO, Italy"
    }
];